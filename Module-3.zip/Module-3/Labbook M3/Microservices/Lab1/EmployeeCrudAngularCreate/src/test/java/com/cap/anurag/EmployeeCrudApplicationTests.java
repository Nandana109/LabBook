package com.cap.anurag;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
